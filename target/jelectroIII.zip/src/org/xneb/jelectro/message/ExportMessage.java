package org.xneb.jelectro.message;

import org.apache.log4j.Logger;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.node.NodeKey;
import org.xneb.jelectro.node.NodePath;
import org.xneb.jelectro.processor.MessageProcessorManager;

@Deprecated
public class ExportMessage extends Message {

	private static transient final Logger log = Logger.getLogger(ExportMessage.class);

	private static final long serialVersionUID = -2146042538791403067L;

	private final String stubName;
	private final Class<?> stubInterface;
	private final NodeKey locationNodeKey;
	private final NodePath[] currentNodePathes;

	public ExportMessage(String stubName, Class<?> stubInterface, NodeKey locationNodeKey, NodePath[] currentNodePath) {
		super();
		this.stubName = stubName;
		this.stubInterface = stubInterface;
		this.locationNodeKey = locationNodeKey;
		this.currentNodePathes = currentNodePath;
	}

	@Override
	public <M extends Message> void process(MessageProcessorManager messageProcessor, MessageTransporter<M> transporter) {
		try {
			messageProcessor.getExportMessageProcessor().processMessage(this, (MessageTransporter<ExportMessage>) transporter);
		} catch (JElectroException e) {
			log.error("Unexpected error", e);
		}

	}

	public String getStubName() {
		return stubName;
	}

	public Class<?> getStubInterface() {
		return stubInterface;
	}

	public NodePath[] getCurrentNodePathes() {
		return currentNodePathes;
	}

	public NodeKey getLocationNodeKey() {
		return locationNodeKey;
	}

	

}

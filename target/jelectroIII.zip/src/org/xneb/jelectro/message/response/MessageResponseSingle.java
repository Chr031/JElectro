package org.xneb.jelectro.message.response;

import org.xneb.jelectro.message.Message;

public class MessageResponseSingle<M extends Message> implements IMessageResponse<M> {

	private final Object lock;

	private final long messageId;

	private Response<M> response;

	public MessageResponseSingle(long messageId) {
		this.lock = new Object();
		this.messageId = messageId;
	}

	/* (non-Javadoc)
	 * @see org.xneb.jelectro.message.MessageResponseI#getMessageId()
	 */
	@Override
	public long getMessageId() {
		return messageId;
	}

	
	@Override
	public Response<M> peekResponse() {
		return response;
	}

	@Override
	public Response<M> poolResponse() throws InterruptedException {
		if (response == null) {
			try {
				synchronized (lock) {
					while (response == null) {
						lock.wait();
					}
				}
			} catch (InterruptedException ie) {
				// ignore
			}
		}
		return response;
	}

	@Override
	public void addMessage(M message) {
		addResponse(message, null);
		
	}

	@Override
	public void addError(Throwable t) {
		addResponse(null, t);
		
	}

	@Override
	public void addResponse(M message, Throwable t) {
		response = new Response<M> (message, t);
		synchronized (lock) {
			lock.notifyAll();
		}
	}

}

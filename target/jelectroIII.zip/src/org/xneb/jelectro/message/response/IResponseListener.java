package org.xneb.jelectro.message.response;

import org.xneb.jelectro.message.Message;

public interface IResponseListener<M extends Message> {

	public void onResponseReceived(Response<M> response);
	
}

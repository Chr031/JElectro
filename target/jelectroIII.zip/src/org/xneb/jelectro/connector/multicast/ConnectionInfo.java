package org.xneb.jelectro.connector.multicast;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;

class ConnectionInfo implements Serializable {

	private static final long serialVersionUID = 5593597119687602376L;

	private final String address;

	private final int port;

	protected ConnectionInfo(String address, int port) {
		super();
		this.address = address;
		this.port = port;
	}

	/**
	 * Creates a instance of this class where the address is the local lan
	 * address of the computer running the JVM. <br>
	 * TODO : check the behavior in case of multiple network interfaces.
	 * 
	 * 
	 * @param port
	 * @throws UnknownHostException 
	 */
	public ConnectionInfo(int port) throws UnknownHostException {
		this.port = port;
		this.address = InetAddress.getLocalHost().getHostAddress();
	}

	public String getAddress() {
		return address;
	}

	public int getPort() {
		return port;
	}
}
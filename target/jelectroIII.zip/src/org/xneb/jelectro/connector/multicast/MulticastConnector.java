package org.xneb.jelectro.connector.multicast;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.xneb.jelectro.connector.IConnector;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.node.INodeListener;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.utils.MulticastMessenger;
import org.xneb.jelectro.utils.MulticastMessenger.MulticastResponseListener;

public class MulticastConnector {

	private final int port;
	private MulticastMessenger<ConnectionLocatorMessage> multicastMessenger;
	private MulticastResponseListener<ConnectionLocatorMessage> responseListener;

	private boolean isConnected;
	private final Object waitForConnectionLock;
	private final List<ConnectionInfo> connectionInfoList;

	public MulticastConnector(int port) {

		this.port = port;
		isConnected = false;
		waitForConnectionLock = new Object();
		connectionInfoList = new ArrayList<ConnectionInfo>();

	}

	public void start() throws IOException {
		if (multicastMessenger != null)
			multicastMessenger.close();
		multicastMessenger = new MulticastMessenger<ConnectionLocatorMessage>(port);

	}

	public void stop() {

		if (multicastMessenger != null)
			multicastMessenger.close();

	}

	public ConnectionState lookForExistingServersOrRegisterServer(Node node, int serverListenerPort) throws IOException, JElectroException {
		if (multicastMessenger == null)
			throw new JElectroException("Multicast connector is not started");
		ConnectionState state = new ConnectionState(node);
		responseListener = new MulticastConnectorResponseListener(node, state);
		multicastMessenger.addMulticastResponseListener(responseListener);

		// tries to reach servers
		multicastMessenger.send(new ConnectionLocatorMessage(node.getNodeKey(), null));

		// notifies on open ports.
		int[] openPorts = node.getOpenPorts();
		boolean portExist = false;
		for (int port : openPorts) {
			multicastMessenger.send(new ConnectionLocatorMessage(node.getNodeKey(), new ConnectionInfo(port)));
			portExist |= port == serverListenerPort;
		}
		if (!portExist && serverListenerPort > 0) {
			node.listenTo(serverListenerPort);
			multicastMessenger.send(new ConnectionLocatorMessage(node.getNodeKey(), new ConnectionInfo(serverListenerPort)));
		}
		state.setReachable(node.getOpenPorts().length > 0);
		return state;

	}

	private class MulticastConnectorResponseListener implements MulticastResponseListener<ConnectionLocatorMessage> {

		private final Node node;
		private final ConnectionState state;

		public MulticastConnectorResponseListener(Node node, ConnectionState state) {
			this.node = node;
			this.state = state;
		}

		@Override
		public void onResponse(ConnectionLocatorMessage clm) throws UnknownHostException, IOException {

			if (clm.getSenderNodeKey().equals(node.getNodeKey()))
				return;

			int[] openPorts = node.getOpenPorts();
			if (clm.getConnectionInfo() == null && openPorts.length > 0) {
				for (int port : openPorts) {
					multicastMessenger.send(new ConnectionLocatorMessage(node.getNodeKey(), new ConnectionInfo(port)));
				}
			} else if (clm.getConnectionInfo() != null && !isConnected) {
				synchronized (waitForConnectionLock) {
					connectionInfoList.add(clm.getConnectionInfo());
					waitForConnectionLock.notifyAll();
				}
			}

		}

	}

	public class ConnectionState {

		private boolean reachable = false;
		private boolean connected = false;

		private final Node node;
		private final INodeListener nodeListener;

		public ConnectionState(final Node node) {
			this.node = node;
			
			nodeListener = new INodeListener() {
				
							
				@Override
				public void onConnectorRemoved(IConnector connector) {
					connected = node.getConnectorContainer().size() >0;
					synchronized (waitForConnectionLock) {
						waitForConnectionLock.notifyAll();
					}
				}
				
				@Override
				public void onConnectorAdded(IConnector connector) {
					connected = node.getConnectorContainer().size() >0;	
					synchronized (waitForConnectionLock) {
						waitForConnectionLock.notifyAll();
					}
				}
			};
			node.addNodeLIstener(nodeListener);
			
		}

		public boolean isConnected() throws InterruptedException, UnknownHostException, IOException, JElectroException {
			if (!connected) {
				synchronized (waitForConnectionLock) {
					if (!connected) {
						if (connectionInfoList.size() == 0) 
							waitForConnectionLock.wait();
						
						if (node.getConnectorContainer().size() == 0) {
							for (ConnectionInfo connectionInfo : connectionInfoList) {
								node.connectTo(connectionInfo.getAddress(), connectionInfo.getPort());
							}
							connected = node.getConnectorContainer().size()>0 ;

						} // else a connection has already been done !
							// -> do nothing !
					}
				}
			}
			return connected;
		}

		public boolean isReachable() {
			return reachable;
		}

		private void setReachable(boolean reachable) {
			this.reachable = reachable;
		}

	}

}

package org.xneb.jelectro.node;

import java.io.IOException;
import java.lang.reflect.Proxy;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.xneb.jelectro.JElectro;
import org.xneb.jelectro.connector.Connector;
import org.xneb.jelectro.connector.ConnectorContainer;
import org.xneb.jelectro.connector.ConnectorKey;
import org.xneb.jelectro.connector.IConnector;
import org.xneb.jelectro.connector.IConnectorListener;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.exception.PathNotAvailableException;
import org.xneb.jelectro.exception.StubNameAlreadyExistsException;
import org.xneb.jelectro.handler.ProxyCallbackHandler;
import org.xneb.jelectro.message.ErrorMessage;
import org.xneb.jelectro.message.LookupMessage;
import org.xneb.jelectro.message.LookupResultMessage;
import org.xneb.jelectro.message.Message;
import org.xneb.jelectro.message.MessageTransporter;
import org.xneb.jelectro.message.response.IMessageResponse;
import org.xneb.jelectro.message.response.MessageResponseContainer;
import org.xneb.jelectro.message.response.MessageResponseMulti;
import org.xneb.jelectro.message.response.MessageResponseSingle;
import org.xneb.jelectro.processor.ErrorMessageProcessor;
import org.xneb.jelectro.processor.ExecuteMessageProcessor;
import org.xneb.jelectro.processor.ExportMessageProcessor;
import org.xneb.jelectro.processor.LookupMessageProcessor;
import org.xneb.jelectro.processor.MessageProcessorManager;
import org.xneb.jelectro.stubs.FutureStubSet;
import org.xneb.jelectro.stubs.LookupResultStubProducer;
import org.xneb.jelectro.stubs.StubBus;
import org.xneb.jelectro.stubs.StubBus.StubBusListener;
import org.xneb.jelectro.stubs.StubContainer;
import org.xneb.jelectro.stubs.StubReference;
import org.xneb.jelectro.utils.WeakFireListeners;

/**
 * Kind of the main class of this project.
 * 
 * 
 * @author xneb
 * 
 */
public class Node implements IConnectorListener {

	private static final Logger log = Logger.getLogger(Node.class);

	private final ConnectorContainer connectorContainer;
	private final NodeKey nodeKey;
	
	private final List<ServerSocketThread> serverSocketThreads;
	private final ExecutorService executor;

	private final MessageProcessorManager messageProcessorManager;
	private final MessageResponseContainer messageResponseContainer;

	private final StubContainer stubContainer;

	@Deprecated
	private final StubBus stubBus;
	
	private final WeakFireListeners<INodeListener> nodeListeners;
	

	public Node(NodeKey nodeKey) {
		this.nodeKey = nodeKey;
		this.nodeListeners = new WeakFireListeners<INodeListener>();
		this.connectorContainer = new ConnectorContainer();
		this.executor = Executors.newCachedThreadPool();
		serverSocketThreads = new ArrayList<ServerSocketThread>();

		this.stubContainer = new StubContainer();
		this.stubBus = new StubBus();

		this.stubBus.addListener(new StubBusListener() {

			@Override
			public <S> void onStubAdded(StubReference<S> reference) {
				// forward the new reference
				messageProcessorManager.getExportMessageProcessor().exportNewReference(reference);

			}

			@Override
			public <S> void onStubRemoved(StubReference<S> reference) {
				// TODO Auto-generated method stub

			}
		});

		messageResponseContainer = new MessageResponseContainer();

		this.messageProcessorManager = new MessageProcessorManager();
		messageProcessorManager.setExportMessageProcessor(new ExportMessageProcessor(this));
		messageProcessorManager.setExecuteMessageProcessor(new ExecuteMessageProcessor(this));
		messageProcessorManager.setErrorMessageProcessor(new ErrorMessageProcessor(this));
		messageProcessorManager.setLookupMessageProcessor(new LookupMessageProcessor(this));

	}

	public NodeKey getNodeKey() {
		return this.nodeKey;
	}
	
	public void addNodeLIstener(INodeListener nl) {
		nodeListeners.addListener(nl);
	}

	public ConnectorContainer getConnectorContainer() {
		return connectorContainer;
	}

	public MessageResponseContainer getMessageResponseContainer() {
		return messageResponseContainer;
	}

	/**
	 * Return the reference of the container that owns all the stub instances
	 * present in this node.
	 * 
	 * @return
	 */
	public StubContainer getStubContainer() {
		return stubContainer;
	}

	/**
	 * Return the container that owns all the stub references exported in this
	 * network.
	 * 
	 * @return
	 */
	public StubBus getStubBus() {
		return this.stubBus;

	}

	@Deprecated
	public <S> void export(String stubName, S stubInstance, Class<S> stubInterface) throws JElectroException {
		bind(stubName, stubInstance);
		stubBus.addStub(stubName, stubInterface, nodeKey, new NodePath(nodeKey));
		if (JElectro.isDebugMode())
			log.debug("Stub " + stubName + " " + stubInstance + " exported");
	}

	@Deprecated
	public <S> Object reExport(String stubName, S stubInstance, Class<S> stubInterface) throws JElectroException {
		if (!stubContainer.contains(stubName))
			throw new JElectroException(String.format("No stub with name '%s' are present", stubName));
		return stubContainer.addStub(stubName, stubInstance);
	}

	public void bind(String stubName, Object stubInstance) throws StubNameAlreadyExistsException {
		if (stubContainer.contains(stubName))
			throw new StubNameAlreadyExistsException(stubName);
		stubContainer.addStub(stubName, stubInstance);

	}

	public Object unbind(String stubName) throws JElectroException {
		if (!stubContainer.contains(stubName))
			throw new JElectroException(String.format("No stub with name '%s' are present", stubName));
		return stubContainer.removeStub(stubName);

	}

	@Deprecated
	public <S> List<S> locate(String stubName, Class<S> stubInterface) {
		List<StubReference<S>> stubReferences = stubBus.getStub(stubName, stubInterface);
		List<S> proxies = new ArrayList<S>();
		for (StubReference<S> reference : stubReferences) {
			if (reference.getLocationNodeKey().equals(nodeKey)) {
				// dummy binding for a local call :
				proxies.add(stubContainer.getStub(stubName, stubInterface));
			} else {
				// TODO use the StubProxyFactory class ....
				// Need to reverse the path because of the way StubReference is
				// build.
				ProxyCallbackHandler proxyHandler = new ProxyCallbackHandler(stubName, this, reference.getPaths()[0].reverse());
				proxyHandler.bindRemoteInterfaceForCallbacks(stubInterface);
				@SuppressWarnings("unchecked")
				S proxy = (S) Proxy.newProxyInstance(stubInterface.getClassLoader(), new Class[] { stubInterface }, proxyHandler);

				proxies.add(proxy);
			}

		}

		return proxies;
	}

	public <S> FutureStubSet<S> lookup(String regexLookupString, Class<S> stubInterface) throws IOException, JElectroException {

		final LookupMessage locateMessage = new LookupMessage(regexLookupString, stubInterface);
		final MessageResponseMulti<LookupResultMessage> response = new MessageResponseMulti<LookupResultMessage>(
				locateMessage.getMessageId());
		final LookupResultStubProducer<S> stubProducer = new LookupResultStubProducer<S>(this, stubInterface, response);
		final FutureStubSet<S> futureStubSet = new FutureStubSet<S>(stubProducer);

		// look for local dummy binding
		for (String stubName : stubContainer.getPublicMatchingStubNames(regexLookupString, stubInterface)) {
			stubProducer.addStub(stubContainer.getStub(stubName, stubInterface));
		}
		// send the message after the FutureStubSet instantiation in order not
		// to loose any messages.
		this.broadcastMessageRegisterResponse(locateMessage, response);

		return futureStubSet;

	}

	/**
	 * Connects to a remote instance. Starts a connector.
	 * 
	 * @param host
	 * @param port
	 * @throws UnknownHostException
	 * @throws IOException
	 * @throws JElectroException
	 */
	public void connectTo(String host, int port) throws UnknownHostException, IOException, JElectroException {
		Socket socket = new Socket(host, port);
		// IConnector connector = new COSConnector(socket, nodeKey, this);
		IConnector connector = new Connector(socket, nodeKey, this);
		connector.init();

	}

	public void listenTo(int port) throws IOException {

		ServerSocketThread serverThread = new ServerSocketThread("JElectroServer-" + port, port);
		serverThread.start();
		serverSocketThreads.add(serverThread);
	}

	public void close() {
		connectorContainer.closeAllConnectors();
		for (ServerSocketThread sst : serverSocketThreads) {
			try {
				sst.close();
			} catch (IOException e) {
				onError(null, e);
			}
		}
		executor.shutdownNow();
	}

	/**
	 * TODO this method should be synchronized in some way with
	 * {@link #serverSocketThreads};
	 * 
	 * @return les list of the current open ports.
	 */
	public int[] getOpenPorts() {
		int[] openPorts = new int[serverSocketThreads.size()];
		for (int i = 0; i < serverSocketThreads.size(); i++) {
			openPorts[i] = serverSocketThreads.get(i).serverSocketPort;
		}
		return openPorts;
	}

	/**
	 * Use this method only if the response is different from the original
	 * message.
	 * 
	 * @param message
	 * @param response
	 * @param destinationPath
	 * @throws IOException
	 * @throws JElectroException
	 */
	public <M extends Message, R extends Message> void sendMessageRegisterResponse(M message, MessageResponseSingle<R> response,
			NodePath destinationPath) throws IOException, JElectroException {
		messageResponseContainer.registerResponse(response);
		MessageTransporter<M> transporter = new MessageTransporter<M>(destinationPath, message);
		forwardMessage(transporter);
	}

	/**
	 * Broadcast the message to all adjacent connectors. Use this method only if
	 * the response is different from the original message.
	 * 
	 * @param message
	 * @param response
	 * @param destinationPath
	 * @throws IOException
	 * @throws JElectroException
	 */
	public <M extends Message, R extends Message> void broadcastMessageRegisterResponse(M message, IMessageResponse<R> response)
			throws IOException, JElectroException {
		messageResponseContainer.registerResponse(response);

		for (ConnectorKey cKey : getConnectorContainer().getConnectorKeys()) {
			MessageTransporter<M> transporter = new MessageTransporter<M>(new NodePath(this.getNodeKey(), cKey.getRemoteNodeKey()), message);
			forwardMessage(transporter);
		}
	}

	/**
	 * Use this method if the response is the same as the original message.
	 * 
	 * @param message
	 * @param path
	 * @return
	 * @throws IOException
	 * @throws JElectroException
	 */
	public <M extends Message> IMessageResponse<M> sendMessageWithResponse(M message, NodePath path) throws IOException, JElectroException {
		IMessageResponse<M> response = messageResponseContainer.createMessageResponseSingle(message);
		MessageTransporter<M> transporter = new MessageTransporter<M>(path, message);
		forwardMessage(transporter);
		return response;
	}

	public <M extends Message> void sendMessageSafe(M message, NodePath path) {
		MessageTransporter<M> transporter = new MessageTransporter<M>(path, message);
		safeForwardMessage(transporter);
	}

	@Override
	public void onInit(IConnector connector) {
		connectorContainer.addConnector(connector);
		if (JElectro.isDebugMode())
			log.debug("In " + connectorContainer + " connector added " + connector.getKey());

	}

	@Override
	public void onStart(IConnector connector) {
		// share the stub bus data :
		for (StubReference<?> ref : stubBus.stubSet()) {
			try {
				messageProcessorManager.getExportMessageProcessor().exportNewReference(connector, ref);
			} catch (IOException e) {
				onError(connector, e);
			}
		}
		if (JElectro.isDebugMode())
			log.debug("Stub references exported");

		if (nodeListeners.getFireProxy() != null)
			nodeListeners.getFireProxy().onConnectorAdded(connector);
		
	}

	@Override
	public void onClose(IConnector connector) {
		connectorContainer.removeConnector(connector);
		if (JElectro.isDebugMode())
			log.debug("In " + connectorContainer + " connector removed " + connector.getKey());
		
		if (nodeListeners.getFireProxy() != null)
			nodeListeners.getFireProxy().onConnectorRemoved(connector);

	}

	@Override
	public <M extends Message> void onMessageTransporterReceive(IConnector connector, MessageTransporter<M> transporter) {
		boolean isAtDestination = transporter.isDestination(nodeKey);
		if (isAtDestination) {
			processMessage(transporter);
		} else {
			safeForwardMessage(transporter);
		}

	}

	@Override
	public void onError(IConnector connector, Throwable error) {
		if (connector != null)
			log.error("Error on connector " + connector.getKey(), error);
		else
			log.error("Unforwardable error :", error);

	}

	private <M extends Message> void processMessage(final MessageTransporter<M> transporter) {
		Runnable processorThread = new Runnable() {
			public void run() {
				try {
					messageProcessorManager.processMessage(transporter);
				} catch (Throwable error) {
					reverseMessageOnError(transporter, error);
				}
			}
		};

		executor.execute(processorThread);
	}

	private <M extends Message> void forwardMessage(MessageTransporter<M> transporter) throws IOException, JElectroException {

		NodeKey nextNodeKey = transporter.getNextNode(nodeKey);
		IConnector connector = connectorContainer.getConnector(new ConnectorKey(nodeKey, nextNodeKey));

		boolean isMessageSent = false;
		Throwable error = null;
		if (connector != null) {
			try {
				connector.sendMessageTransporter(transporter);
				isMessageSent = true;
			} catch (Throwable t) {
				isMessageSent = false;
				error = t;
			}
		}
		if (!isMessageSent) {
			JElectroException ex;
			if (connector == null) {
				ex = new PathNotAvailableException(String.format("Path not found : [%1$s - %2$s] ", nodeKey, nextNodeKey));
			} else {
				ex = new PathNotAvailableException(
						String.format("Error on sending message between : [%1$s - %2$s] ", nodeKey, nextNodeKey), error);
			}

			if (!(transporter.getMessage() instanceof ErrorMessage)) {
				reverseMessageOnError(transporter, ex);
			} else {
				throw ex;
			}
		}
	}

	private <M extends Message> void safeForwardMessage(MessageTransporter<M> transporter) {

		try {
			forwardMessage(transporter);
		} catch (IOException e) {
			onError(null, e);
		} catch (JElectroException e) {
			onError(null, e);
		}

	}

	private <M extends Message> void reverseMessageOnError(MessageTransporter<M> transporter, Throwable error) {
		M m = transporter.getMessage();
		ErrorMessage<M> errorMessage = new ErrorMessage<M>(m, error);
		MessageTransporter<ErrorMessage<M>> reverse = new MessageTransporter<ErrorMessage<M>>(transporter.getNodePath().reverse(),
				errorMessage);
		if (reverse.getDestination().equals(nodeKey)) {
			// message error has to be processed somehow by the processor !
			try {
				messageProcessorManager.processMessage(reverse);
			} catch (Throwable t) {
				onError(null, t);
			}
		} else {
			safeForwardMessage(reverse);
		}

	}

	private class ServerSocketThread extends Thread {

		private final int serverSocketPort;
		private final ServerSocket serverSocket;
		private volatile boolean active;

		public ServerSocketThread(String threadName, int port) throws IOException {
			super(threadName);
			this.serverSocketPort = port;
			this.serverSocket = new ServerSocket(port);
		}

		protected void close() throws IOException {
			active = false;
			this.interrupt();
			serverSocket.close();
		}

		public void run() {
			active = true;
			while (active) {
				final Socket socket;
				IConnector connector = null;
				try {
					socket = serverSocket.accept();
					connector = new Connector(socket, nodeKey, Node.this);
					connector.init();
				} catch (SocketException se) {
					if (!se.getMessage().equalsIgnoreCase("socket closed")) {
						onError(connector, se);
					}
				} catch (Throwable t) {
					onError(connector, t);
				}
			}
		}
	}

}

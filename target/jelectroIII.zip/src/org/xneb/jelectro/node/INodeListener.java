package org.xneb.jelectro.node;

import org.xneb.jelectro.connector.IConnector;

public interface INodeListener {

	void onConnectorAdded(IConnector connector) ;
	
	void onConnectorRemoved(IConnector connector);
	
}

package org.xneb.jelectro.utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Set;
import java.util.WeakHashMap;

public class WeakFireListeners<L> {

	private final WeakHashMap<L, Void> lMap;
	private L fireProxy;

	/**
	 * Checks that L represents an interface and not something else.
	 */
	public WeakFireListeners() {
		lMap = new WeakHashMap<L, Void>();
	}

	@SuppressWarnings("unchecked")
	public void addListener(L listener) {
		if (fireProxy == null && listener != null) {
			initFireProxy((Class<L>) listener.getClass());
		}
		lMap.put(listener, null);
	}

	@SuppressWarnings("unchecked")
	public void addListeners(L... listeners) {
		if (fireProxy == null && listeners.length > 0) {
			initFireProxy((Class<L>) listeners[0].getClass());
		}

		for (L l : listeners) {
			lMap.put(l, null);
		}
	}

	public Set<L> getListeners() {
		return lMap.keySet();
	}

	@SuppressWarnings("unchecked")
	protected void initFireProxy(Class<L> clazz) {
		InvocationHandler handler = new FireInvocationHandler();
		fireProxy = (L) Proxy.newProxyInstance(clazz.getClassLoader(), clazz.isInterface() ? new Class[] {clazz} : clazz.getInterfaces(), handler);
	}

	/**
	 * See {@link #initFireProxy(Class)}
	 * 
	 * @return a {@link Proxy} instance of L that can trigger all listener's
	 *         events or null if {@link #initFireProxy(Class)} has not been
	 *         called.
	 */
	public L getFireProxy() {

		return fireProxy;
	}

	private class FireInvocationHandler implements InvocationHandler {

		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			for (L l : getListeners()) {
				method.invoke(l, args);
			}
			return null;
		}

	}

}

package org.xneb.jelectro.exception;

public class UntransportableTypeException extends JElectroException {

	private static final long serialVersionUID = -79472300339076720L;

	public UntransportableTypeException(String message) {
		super(message);
		
	}

}

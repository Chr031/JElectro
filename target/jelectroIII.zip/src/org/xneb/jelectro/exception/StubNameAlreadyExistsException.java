package org.xneb.jelectro.exception;

public class StubNameAlreadyExistsException extends JElectroException {

	public StubNameAlreadyExistsException(String stubName) {
		super(String.format("this name '%s' is already used", stubName));
		
	}

}

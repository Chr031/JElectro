package org.xneb.jelectro;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.xneb.jelectro.connector.ConnectorKey;
import org.xneb.jelectro.connector.IConnector;
import org.xneb.jelectro.connector.multicast.MulticastConnector;
import org.xneb.jelectro.connector.multicast.MulticastConnector.ConnectionState;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.exception.StubNameAlreadyExistsException;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodeKey;
import org.xneb.jelectro.node.NodeService;
import org.xneb.jelectro.stubs.FutureStubSet;

public class JElectro {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(JElectro.class);

	private static boolean debugMode = false;
	private static boolean infoMode = false;

	private final String nodeName;
	private final Node node;
	private final NodeService nodeService;

	private MulticastConnector multicastConnector;

	/**
	 * Creates a new instance of JElectro node with the given name.
	 * 
	 * @param nodeName
	 */
	public JElectro(String nodeName) {
		super();
		this.nodeName = nodeName;
		nodeService = new NodeService();

		this.node = new Node(nodeService.createNodeKey(this.nodeName));

	}

	public NodeKey getNodeKey() {
		return node.getNodeKey();
	}
	
	public int[] getOpenPorts() {
		return node.getOpenPorts();
	}

	/**
	 * This method sends multicast messages to locate any {@link JElectro}
	 * servers on a Lan. If none are found, it will open a port for
	 * {@link JElectro} instances to connect to.
	 * 
	 * @param mutlicastPort
	 * @param serverListenerPort
	 * @throws IOException
	 * @throws JElectroException 
	 */
	public ConnectionState startLanDiscovery(int mutlicastPort, int serverListenerPort) throws IOException, JElectroException {
		if (multicastConnector != null)
			multicastConnector.stop();
		multicastConnector = new MulticastConnector(mutlicastPort);
		multicastConnector.start();
		return multicastConnector.lookForExistingServersOrRegisterServer(this.node, serverListenerPort);
	}

	/**
	 * Open a port on the local instance and listen to incoming connections and
	 * messages.
	 * 
	 * @param port
	 * @throws IOException
	 * @throws JElectroException
	 */
	public void listenTo(int port) throws IOException, JElectroException {
		node.listenTo(port);
	}

	protected List<ConnectorKey> getActiveConnections() {
		List<ConnectorKey> keys = new ArrayList<ConnectorKey>();
		Iterator<IConnector> iter = node.getConnectorContainer().iterator();
		while (iter.hasNext()) {
			keys.add(iter.next().getKey());
		}
		return keys;
	}

	/**
	 * Connect to a remote instance located on host:port.
	 * 
	 * @param host
	 * @param port
	 * @throws IOException
	 * @throws JElectroException
	 */
	public void connectTo(String host, int port) throws IOException, JElectroException {
		node.connectTo(host, port);
	}

	public <S> void bind(String stubName, S stubInstance) throws StubNameAlreadyExistsException {
		node.bind(stubName, stubInstance);
	}

	public void unbind(String stubName) throws JElectroException {
		node.unbind(stubName);
	}

	public <S> FutureStubSet<S> lookup(String regexLocateString, Class<S> stubInterface) throws IOException, JElectroException {
		return node.lookup(regexLocateString, stubInterface);
	}

	public <S> S lookupUnique(String regexLocateString, Class<S> stubInterface) throws IOException, JElectroException {
		return node.lookup(regexLocateString, stubInterface).get(0);
	}

	public void close() {
		node.close();

	}

	@Deprecated
	public <S> void export(String stubName, S stubInstance, Class<S> stubInterface) throws JElectroException {
		node.export(stubName, stubInstance, stubInterface);
	}

	@Deprecated
	public <S> void reExport(String stubName, S stubInstance, Class<S> stubInterface) throws JElectroException {
		node.reExport(stubName, stubInstance, stubInterface);
	}

	/**
	 * 
	 * @param stubName
	 * @param stubInterface
	 * @return
	 */
	@Deprecated
	public <S> List<S> locate(String stubName, Class<S> stubInterface) {
		return node.locate(stubName, stubInterface);
	}

	/**
	 * 
	 * @param stubName
	 * @param stubInterface
	 * @return
	 * @throws JElectroException
	 */
	@Deprecated
	public <S> S locateUnique(String stubName, Class<S> stubInterface) throws JElectroException {
		List<S> stubs = locate(stubName, stubInterface);
		if (stubs.size() != 1)
			throw new JElectroException("No unique stub with name " + stubName + ". Number is " + stubs.size());
		return stubs.get(0);
	}

	public static boolean isDebugMode() {
		return debugMode;
	}

	public static void setDebugMode(boolean debugMode) {
		JElectro.debugMode = debugMode;
		JElectro.infoMode |= debugMode; 
	}

	public static boolean isInfoMode() {
		return infoMode;
	}

	public static void setInfoMode(boolean infoMode) {
		JElectro.infoMode = infoMode;
		JElectro.debugMode &= infoMode;
	}

}

package org.xneb.jelectro.stubs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FutureStubSet<S> implements StubSet<S>, IStubProducerListener<S> {

	private final IStubProducer<S> stubProducer;
	private final List<S> stubList;
	private final Object lock;

	public FutureStubSet(IStubProducer<S> stubProducer) {
		this.stubProducer = stubProducer;
		this.stubList = new ArrayList<S>();
		this.lock = new Object();
		stubProducer.addStubProducerListener(this);
	}

	@Override
	public S getLoadBalancedStatelessStub() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public S getLoadBalancedStatefullStub() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<S> iterator() {
		final List<S> tmpList;
		synchronized (lock) {
			tmpList = new ArrayList<S>(stubList.size());
			tmpList.addAll(stubList);
		}
		return tmpList.iterator();
	}

	/**
	 * Method that blocks until at least i stubs are present in this instance.
	 * 
	 * @param i
	 */
	public void waitFor(int i) {
		if (stubList.size() < i) {
			synchronized (lock) {
				try {
					while (stubList.size() < i) {
						lock.wait();
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void onStubProduced(S stub) {
		synchronized (lock) {
			stubList.add(stub);
			lock.notifyAll();
		}
	}

	@Override
	public IStubProducer<S> getStubProducer() {
		return stubProducer;
	}

	@Override
	public int size() {
		return stubList.size();
	}

	@Override
	public S get(int i) {
		waitFor(i+1);
		return stubList.get(i);
	}

}

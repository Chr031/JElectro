package org.xneb.jelectro.stubs;

import org.xneb.jelectro.message.LookupResultMessage;
import org.xneb.jelectro.message.response.IResponseListener;
import org.xneb.jelectro.message.response.MessageResponseMulti;
import org.xneb.jelectro.message.response.Response;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.utils.WeakFireListeners;

public class LookupResultStubProducer<S> implements IStubProducer<S>, IResponseListener<LookupResultMessage> {

	private final WeakFireListeners<IStubProducerListener<S>> listeners;
	private final MessageResponseMulti<LookupResultMessage> messageResponse;
	private final Node node;
	private final Class<S> stubInterface;

	public LookupResultStubProducer(Node node, Class<S> stubInterface, MessageResponseMulti<LookupResultMessage> messageResponse) {
		this.listeners = new WeakFireListeners<IStubProducerListener<S>>();
		this.node = node;
		this.stubInterface = stubInterface;
		this.messageResponse = messageResponse;

		messageResponse.addResponseListener(this);
	}

	public MessageResponseMulti<LookupResultMessage> getMessageResponse() {
		return messageResponse;
	}

	@Override
	public void addStubProducerListener(IStubProducerListener<S> spl) {
		listeners.addListener(spl);
	}

	@Override
	public void onResponseReceived(Response<LookupResultMessage> response) {

		if (response.getMessage() != null) {
			LookupResultMessage message = response.getMessage();
			for (String stubName : message.getMatchingStubNames()) {
				S newProxyStub = StubProxyFactory.createStubProxy(node, stubName, stubInterface, message.getStubNodePath());
				addStub(newProxyStub);
			}
		}
	}

	@Override
	public void addStub(S stub) {
		listeners.getFireProxy().onStubProduced(stub);
	}

}

package org.xneb.jelectro.stubs;

public interface IStubProducerListener<S> {

	public void onStubProduced(S stub);
	
}

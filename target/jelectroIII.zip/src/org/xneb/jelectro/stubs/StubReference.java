package org.xneb.jelectro.stubs;

import org.xneb.jelectro.node.NodeKey;
import org.xneb.jelectro.node.NodePath;
import org.xneb.jelectro.node.NodePathList;

public class StubReference<S> {

	private final String name;
	private final Class<S> stubInterface;
	private final NodeKey locationNodeKey;
	private final NodePathList nodePaths;
	
	public StubReference(String name, Class<S> stubInterface, NodeKey locationNodeKey) {
		super();
		this.name = name;
		this.stubInterface = stubInterface;
		this.locationNodeKey = locationNodeKey;
		nodePaths = new NodePathList();
	}

	public String getName() {
		return name;
	}

	public Class<S> getStubInterface() {
		return stubInterface;
	}

	public NodeKey getLocationNodeKey() {
		return locationNodeKey;
	}

	/**
	 * <p>
	 * Returns the path to reach the node where the stub instance lies. This
	 * path should be a full path starting from the current node key of the
	 * reference node owner and ending with the locationNodeKey.
	 * </p>
	 * <p>
	 * Having more than one path means that the stub is reachable from multiple
	 * ways.
	 * </p>
	 * 
	 * @return
	 */
	public NodePath[] getPaths() {
		return nodePaths.getPathes();
	}

	public void addPath(NodePath path) {
		nodePaths.addNodePath(path);
	}

	public void removePath(NodePath path) {
		nodePaths.removeNodePath(path);
	}
	
	public  boolean matches(String stubName, Class<S> stubInterface) {
		if (name == null) {
			if (stubName != null)
				return false;
		} else if (!name.equals(stubName))
			return false;
		if (this.stubInterface == null) {
			if (stubInterface != null)
				return false;
		} else if (!this.stubInterface.equals(stubInterface))
			return false;
		return true;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((locationNodeKey == null) ? 0 : locationNodeKey.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((stubInterface == null) ? 0 : stubInterface.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StubReference other = (StubReference) obj;
		if (locationNodeKey == null) {
			if (other.locationNodeKey != null)
				return false;
		} else if (!locationNodeKey.equals(other.locationNodeKey))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (stubInterface == null) {
			if (other.stubInterface != null)
				return false;
		} else if (!stubInterface.equals(other.stubInterface))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StubReference [name=" + name + ", stubInterface=" + stubInterface + ", locationNodeKey=" + locationNodeKey + "]";
	}

}
package org.xneb.jelectro.stubs;


public interface StubSet<S> extends Iterable<S> {

	public S getLoadBalancedStatelessStub() ;
	
	public S getLoadBalancedStatefullStub() ;

	public abstract S get(int i);

	public abstract int size();

	public abstract IStubProducer<S> getStubProducer();
	
	
}

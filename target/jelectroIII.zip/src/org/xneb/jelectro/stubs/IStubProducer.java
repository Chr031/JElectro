package org.xneb.jelectro.stubs;

public interface IStubProducer<S> {
	
	
	public void addStub(S stub);
	
	public void addStubProducerListener(IStubProducerListener<S> spl);
	
		
}

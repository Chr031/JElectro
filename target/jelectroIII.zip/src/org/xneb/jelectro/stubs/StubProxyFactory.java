package org.xneb.jelectro.stubs;

import java.lang.reflect.Proxy;

import org.xneb.jelectro.handler.ProxyCallbackHandler;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodePath;

public class StubProxyFactory {

	public static <S> S createStubProxy(Node node, String stubName, Class<S> stubInterface, NodePath stubNodePath ) {
		
		ProxyCallbackHandler proxyHandler = new ProxyCallbackHandler(stubName, node, stubNodePath);
		proxyHandler.bindRemoteInterfaceForCallbacks(stubInterface);
		@SuppressWarnings("unchecked")
		S proxy = (S) Proxy.newProxyInstance(stubInterface.getClassLoader(), new Class[] { stubInterface }, proxyHandler);
		return proxy;
	}
	
}

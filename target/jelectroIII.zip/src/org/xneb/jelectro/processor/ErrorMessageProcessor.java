package org.xneb.jelectro.processor;

import org.xneb.jelectro.message.ErrorMessage;
import org.xneb.jelectro.message.Message;
import org.xneb.jelectro.message.MessageTransporter;
import org.xneb.jelectro.message.response.IMessageResponse;
import org.xneb.jelectro.node.Node;

public class ErrorMessageProcessor {

	private final Node node;

	public ErrorMessageProcessor(Node node) {
		this.node = node;
	}
	
	public <M extends Message> void processMessage(ErrorMessage<M> errorMessage, MessageTransporter<ErrorMessage<M>> transporter) throws InterruptedException {
		IMessageResponse<M> response = node.getMessageResponseContainer().getMessageResponse(errorMessage.getOriginalMessage());
		if (response != null) response.addError(errorMessage.getError());
	}
	
}

package org.xneb.jelectro.processor;

import java.io.IOException;
import java.util.Iterator;

import org.xneb.jelectro.connector.Connector;
import org.xneb.jelectro.connector.IConnector;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.message.ExportMessage;
import org.xneb.jelectro.message.MessageTransporter;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodeKey;
import org.xneb.jelectro.node.NodePath;
import org.xneb.jelectro.stubs.StubReference;

public class ExportMessageProcessor {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ExportMessageProcessor.class);

	private Node node;

	public ExportMessageProcessor(Node node) {
		this.node = node;
	}

	/**
	 * This method receives an {@link ExportMessage} and add the stub to the underlying stub bus of the local node.
	 * @param message
	 * @param transporter
	 * @throws JElectroException 
	 */
	@SuppressWarnings("unchecked")
	public void processMessage(ExportMessage message, MessageTransporter<ExportMessage> transporter) throws JElectroException {

		NodePath[] pathes = message.getCurrentNodePathes();
		for (NodePath path : pathes) {
			NodePath stubNodePath = new NodePath(path, node.getNodeKey());
			// Since the message is coming from the owner node of the stub, the path has to be reversed in order to point to the good destination !
			// stubNodePath = stubNodePath.reverse();
			node.getStubBus().addStub(message.getStubName(), message.getStubInterface(), message.getLocationNodeKey(), stubNodePath);
		}

	}

	/**
	 * <p>
	 * This method forward the reference to every connected node except the one
	 * that has sent it and/or the one that does belong to the path of this reference.
	 * </p>
	 * <p>
	 * This is a way to propagate the existence of this stub reference.
	 * </p>
	 * 
	 * @param reference
	 */
	public <S> void exportNewReference(StubReference<S> reference) {

		log.debug("Start exporting reference " + reference);

		NodePath[] pathes = reference.getPaths();
		NodeKey[] nextNodeKeys = new NodeKey[pathes.length];
		for (int i = 0; i < nextNodeKeys.length; i++) {
			nextNodeKeys[i] = pathes[i].getNextNode(node.getNodeKey());
		}
		
		Iterator<IConnector> iter = node.getConnectorContainer().iterator();
		while (iter.hasNext()) {
			IConnector connector = iter.next();
			/**
			 * This is a way to check that the reference will not be sent to a node that have already this reference 
			 * and that the path to this reference is not going throw this node. 
			 */
			for (NodeKey nextNodeKey : nextNodeKeys) {
				if (connector.getKey().getRemoteNodeKey().equals(nextNodeKey)) {
					continue;
				}
			}
			try {
				// forward the message
				sendReferenceToConnector(connector, reference);
			} catch (Exception e) {
				node.onError(connector, e);
			}
		}

	}

	private <S> void sendReferenceToConnector(IConnector connector, StubReference<S> reference) throws IOException {
		ExportMessage export = new ExportMessage(reference.getName(), reference.getStubInterface(), reference.getLocationNodeKey(),	reference.getPaths());
		MessageTransporter<ExportMessage> transporter = new MessageTransporter<ExportMessage>(new NodePath(node.getNodeKey(), connector.getKey().getRemoteNodeKey()), export);
		connector.sendMessageTransporter(transporter);
		log.debug(reference + " exported to " + transporter.getDestination());

	}

	public <S> void exportNewReference(IConnector connector, StubReference<S> reference) throws IOException {
		log.debug("Start exporting reference " + reference + " to connector " + connector);
		if (!reference.getLocationNodeKey().equals(connector.getKey().getRemoteNodeKey())) {
			sendReferenceToConnector(connector, reference);
		}
	}
}

package org.xneb.jelectro.processor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.xneb.jelectro.connector.ConnectorKey;
import org.xneb.jelectro.message.LookupMessage;
import org.xneb.jelectro.message.LookupResultMessage;
import org.xneb.jelectro.message.MessageTransporter;
import org.xneb.jelectro.message.response.IMessageResponse;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodeKey;
import org.xneb.jelectro.node.NodePath;

public class LookupMessageProcessor {

	private final Node node;

	private final Set<Long> processedLocateMessage;

	public LookupMessageProcessor(Node node) {
		this.node = node;
		processedLocateMessage = new HashSet<Long>();
	}

	/**
	 * <ul>
	 * Processes a locate message.
	 * 
	 * <li>Looks if a stub present in this node is not matching the current
	 * {@link LookupMessage#getSearchString()} value. if yes, sends back a
	 * {@link LookupResultMessage}</li>
	 * <li>Check if this locate message has already been treated.</li><li> If not,
	 * forwards it to all connectors (but not the incoming one).</li>
	 * </ul>
	 * 
	 * @param lookupMessage
	 * @param transporter
	 */
	public void processMessage(LookupMessage lookupMessage, MessageTransporter<LookupMessage> transporter) {

		// TODO : Check if the regex is valid according to the path....

		// 1-
		String[] matchingStubNames = node.getStubContainer().getPublicMatchingStubNames(lookupMessage.getStubNameRegEx(),
				lookupMessage.getStubInterface());
		if (matchingStubNames.length > 0) {
			LookupResultMessage lookupResultMessage = new LookupResultMessage(lookupMessage, matchingStubNames, node.getNodeKey());
			node.sendMessageSafe(lookupResultMessage, transporter.getNodePath().reverse());
		}

		// 2-
		boolean alreadyProcessed = false;
		synchronized (this) {
			alreadyProcessed = processedLocateMessage.contains(lookupMessage.getMessageId());
			if (!alreadyProcessed)
				processedLocateMessage.add(lookupMessage.getMessageId());
		}

		// 3-
		if (!alreadyProcessed) {
			
			NodeKey previousNodeKey = transporter.getPreviousNode(node.getNodeKey());
			List<ConnectorKey> connectorKeys = node.getConnectorContainer().getConnectorKeys();
			for(ConnectorKey key :  connectorKeys) {
				
				if (key.getRemoteNodeKey().equals(previousNodeKey))
					continue;
				
				node.sendMessageSafe(lookupMessage, new NodePath(transporter.getNodePath(), key.getRemoteNodeKey()));
			}
		}
	}
	
	
	/**
	 * Get the MessageResponse and add the new incoming result to it !
	 * @param locateMessage
	 * @param transporter
	 * @throws InterruptedException 
	 */
	public void processMessage(LookupResultMessage lookupResultMessage, MessageTransporter<LookupResultMessage> transporter) throws InterruptedException {

		IMessageResponse<LookupResultMessage> response = node.getMessageResponseContainer().getMessageResponse(lookupResultMessage);
		if (response != null) {
			lookupResultMessage.setStubNodePath(transporter.getNodePath().reverse());
			response.addMessage(lookupResultMessage);
		}
	}
	
}

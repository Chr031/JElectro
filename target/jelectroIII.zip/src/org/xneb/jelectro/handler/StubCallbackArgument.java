package org.xneb.jelectro.handler;

import java.io.Serializable;
import java.lang.reflect.Proxy;
import java.util.Random;

import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodePath;

public class StubCallbackArgument implements Serializable {

	private static final long serialVersionUID = 6120353262544103889L;

	private transient static final Random rand = new Random();

	private final String stubName;

	public StubCallbackArgument(Object stub, Node node) throws JElectroException {
		stubName = "JElectroCallback" + rand.nextInt();
		node.bind(stubName, stub);
	}

	public String getStubName() {
		return stubName;
	}

	protected void unbind(Node node) throws JElectroException {
		node.unbind(stubName);
	}

	public Object getProxy(Class<?> callbackInterface, Node node, NodePath path) {
		ProxyHandler handler = new ProxyHandler(stubName, node, path);
		return Proxy.newProxyInstance(this.getClass().getClassLoader(), new Class<?>[] { callbackInterface }, handler);
	}

}

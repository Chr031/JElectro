package org.xneb.jelectro.handler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.xneb.jelectro.message.ExecuteMessage;
import org.xneb.jelectro.message.ExecuteResultMessage;
import org.xneb.jelectro.message.Message;
import org.xneb.jelectro.message.response.MessageResponseSingle;
import org.xneb.jelectro.message.response.Response;
import org.xneb.jelectro.node.Node;
import org.xneb.jelectro.node.NodePath;
import org.xneb.jelectro.node.NodePathList;

public class ProxyHandler implements InvocationHandler {

	protected final String stubName;

	protected final Node node;
	protected final NodePathList nodePaths;

	/**
	 * TODO should be instantiated with the good node path. No need to reverse
	 * for each call.
	 * 
	 * @param stubName
	 * @param node
	 * @param path
	 */
	public ProxyHandler(String stubName, Node node, NodePath... path) {

		this.stubName = stubName;
		this.node = node;
		this.nodePaths = new NodePathList(path);
	}

	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

		// MessageResponse<ExecuteMessage> response = node.sendMessageWithResponse(new ExecuteMessage(stubName, method, args), nodePath);
		
		final Message message = new ExecuteMessage(stubName, method, args);
		final MessageResponseSingle<ExecuteResultMessage> messageResponse = new MessageResponseSingle<ExecuteResultMessage>(message.getMessageId());
		node.sendMessageRegisterResponse(message, messageResponse, nodePaths.getMainPath());

		final Response<ExecuteResultMessage> response = messageResponse.poolResponse();
		if (response.getError() != null)
			throw response.getError();

		if (response.getMessage().getError() != null)
			throw response.getMessage().getError();

		final Object result = response.getMessage().getResult();

		return result;
	}

}

package org.xneb.jelectro;

import java.io.IOException;

import org.apache.log4j.BasicConfigurator;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.xneb.jelectro.connector.multicast.MulticastConnector.ConnectionState;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.stubs.FutureStubSet;
import org.xneb.jelectro.testobjects.Calc;
import org.xneb.jelectro.testobjects.CalcImpl;

public class JElectroMulticastTest {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(JElectroTest.class);

	@BeforeClass
	public static void initTest() {
		BasicConfigurator.configure();

		JElectro.setDebugMode(true);

	}

	@Test
	public void testMulticastConnection2Instances() throws IOException, JElectroException, InterruptedException {

		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");
		
		try {
		
			ConnectionState cs1 = j1.startLanDiscovery(12354, 12001);
			ConnectionState cs2 = j2.startLanDiscovery(12354, 12002);

			Assert.assertTrue(cs1.isConnected());
			Assert.assertTrue(cs2.isConnected());

			Calc c = new CalcImpl();
			j1.bind("calc1", c);
			
			Calc cr = j2.lookupUnique("calc1", Calc.class) ;
			
			int i = cr.add(123 , 456 ,789);
			
			System.out.println(i);
			
			
		} finally {
			j1.close();
			j2.close();
		}
	}

}

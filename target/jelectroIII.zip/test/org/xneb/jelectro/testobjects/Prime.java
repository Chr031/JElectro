package org.xneb.jelectro.testobjects;

import org.xneb.jelectro.JElectroTestWithDeprecatedExportFunction;

public interface Prime {
	void getPrimeNumber(int limit, PrimeSender callback);
}
package org.xneb.jelectro.testobjects;

import org.xneb.jelectro.JElectroCallback;

public interface PrimeSender extends JElectroCallback {
	void onPrime(int primeNumber);
}
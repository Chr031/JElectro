package org.xneb.jelectro.utils;

import java.io.Serializable;

class HelloMulticast implements Serializable {
	int port;
	String hello;

	public HelloMulticast(int port, String hello) {
		super();
		this.port = port;
		this.hello = hello;
	}

}
package org.xneb.jelectro.utils;

import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;

import junit.framework.Assert;

import org.apache.log4j.BasicConfigurator;
import org.junit.BeforeClass;
import org.junit.Test;
import org.xneb.jelectro.JElectro;
import org.xneb.jelectro.utils.MulticastMessenger;
import org.xneb.jelectro.utils.MulticastMessenger.MulticastResponseListener;

public class MulticastMessengerTest {

	
	@BeforeClass 
	public static void init() {
		BasicConfigurator.configure();
		JElectro.setDebugMode(true);
	}
	
	
	@Test
	public void test() throws IOException, InterruptedException {
		MulticastMessenger<HelloMulticast> mm1 = new MulticastMessenger<HelloMulticast>(1524);
		MulticastMessenger<HelloMulticast> mm2 = new MulticastMessenger<HelloMulticast>(1524);
		MulticastMessenger<HelloMulticast> mm3 = new MulticastMessenger<HelloMulticast>(1524);
		
		final ArrayBlockingQueue<HelloMulticast> queue = new ArrayBlockingQueue<HelloMulticast>(100);
		
		MulticastResponseListener<HelloMulticast> mrl = new MulticastResponseListener<HelloMulticast>() {

			@Override
			public void onResponse(HelloMulticast messageReceived) {
				try {
					queue.put(messageReceived);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		};
		mm2.addMulticastResponseListener(mrl);
		mm3.addMulticastResponseListener(mrl);
		
		
		HelloMulticast h = new HelloMulticast(125, "Hello");
		mm1.send(h);
		
		HelloMulticast h1 = queue.take();		
		Assert.assertEquals(h.hello, h1.hello);
		Assert.assertEquals(h.port, h1.port);
		HelloMulticast h2 = queue.take();	
		Assert.assertEquals(h.hello, h2.hello);
		
		
		h = new HelloMulticast(15444, "45677");
		mm1.send(h);
		
		 h1 = queue.take();		
		Assert.assertEquals(h.hello, h1.hello);
		Assert.assertEquals(h.port, h1.port);
		 h2 = queue.take();	
		Assert.assertEquals(h.hello, h2.hello);
		
		mm1.close();
		mm2.close();
		mm3.close();
	}

}

package org.xneb.jelectro;

import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.BasicConfigurator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.xneb.jelectro.exception.JElectroException;
import org.xneb.jelectro.exception.PathNotAvailableException;
import org.xneb.jelectro.stubs.FutureStubSet;
import org.xneb.jelectro.stubs.StubSet;
import org.xneb.jelectro.testobjects.Calc;
import org.xneb.jelectro.testobjects.CalcImpl;
import org.xneb.jelectro.testobjects.Prime;
import org.xneb.jelectro.testobjects.PrimeImpl;
import org.xneb.jelectro.testobjects.PrimeSender;

public class JElectroTest {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(JElectroTest.class);

	@BeforeClass
	public static void initTest() {
		BasicConfigurator.configure();
	}

	@Before
	public void initMode() {
		JElectro.setDebugMode(false);
		JElectro.setInfoMode(true);

	}

	@Test
	public void testJElectroDebugAndInfoMode() {

		JElectro.setDebugMode(true);
		Assert.assertTrue(JElectro.isDebugMode());
		Assert.assertTrue(JElectro.isInfoMode());

		JElectro.setDebugMode(false);
		Assert.assertFalse(JElectro.isDebugMode());
		Assert.assertTrue(JElectro.isInfoMode());

		JElectro.setInfoMode(false);
		Assert.assertFalse(JElectro.isDebugMode());
		Assert.assertFalse(JElectro.isInfoMode());

		JElectro.setInfoMode(true);
		Assert.assertFalse(JElectro.isDebugMode());
		Assert.assertTrue(JElectro.isInfoMode());

		JElectro.setDebugMode(true);
		Assert.assertTrue(JElectro.isDebugMode());
		Assert.assertTrue(JElectro.isInfoMode());

		JElectro.setInfoMode(false);
		Assert.assertFalse(JElectro.isDebugMode());
		Assert.assertFalse(JElectro.isInfoMode());

	}

	/**
	 * This is the simplest test : Check that instances are well defined and
	 * launched. Check that stubs are well instantiated and exported. Check that
	 * stubs are accessible and executable.
	 * 
	 * @throws IOException
	 * @throws JElectroException
	 * @throws InterruptedException
	 */
	@Test
	public void testSingleExportAndExecute() throws IOException, JElectroException, InterruptedException {

		log.info("Start testSingleExportAndExecute");
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		log.info("Instanciation successfull");
		try {
			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Assert.assertEquals(1, j1.getActiveConnections().size());
			Assert.assertEquals(1, j2.getActiveConnections().size());

			log.info("Connection successfull");

			Calc add = new CalcImpl();

			j1.bind("add", add);

			FutureStubSet<Calc> addStubs = j2.lookup("add", Calc.class);
			addStubs.waitFor(1);
			Assert.assertEquals("exported stub is not visible", 1, addStubs.size());
			log.info("Export successfull");

			Calc addStub = addStubs.get(0);
			int sum = addStub.add(1, 2, 3, 4, 5, 6);

			log.info("Sum is : " + sum);
			Assert.assertEquals("Result is not the one expected ", 21, sum);

			log.info("Call successfull");
		} finally {
			j1.close();
			j2.close();
		}
		log.info("Close successfull");

	}

	@Test
	public void testSingleBindLookupAndExecute() throws IOException, JElectroException {
		log.info("Start testSingleExportAndExecute");
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		log.info("Instanciation successfull");
		try {
			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Assert.assertEquals(1, j1.getActiveConnections().size());
			Assert.assertEquals(1, j2.getActiveConnections().size());
			log.info("Connection successfull");

			Calc add = new CalcImpl();

			j1.bind("add", add);
			FutureStubSet<Calc> stubs = j2.lookup("add", Calc.class);
			stubs.waitFor(1);
			for (Calc c : stubs) {
				Assert.assertEquals(6, c.add(1, 2, 3));
			}

			log.info("Call successfull");
		} finally {
			j1.close();
			j2.close();
		}
		log.info("Close successfull");

	}

	@Test
	public void test3InstancesExportAndExecute() throws IOException, JElectroException, InterruptedException {
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");
		JElectro j3 = new JElectro("c");

		log.info("Instanciation successfull");
		try {
			j2.listenTo(12001);
			j1.connectTo("localhost", 12001);
			j3.connectTo("localhost", 12001);

			Thread.yield();

			Assert.assertEquals(1, j1.getActiveConnections().size());
			Assert.assertEquals(2, j2.getActiveConnections().size());
			Assert.assertEquals(1, j3.getActiveConnections().size());

			log.info("Connection successfull");

			Calc addInstance = new CalcImpl();

			j1.bind("add", addInstance);

			StubSet<Calc> addStubs = j3.lookup("add", Calc.class);

			Calc addStub = addStubs.get(0);

			int sum = addStub.add(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

			log.info("Result is : " + sum);
			Assert.assertEquals(55, sum);
		} finally {
			j1.close();
			j2.close();
			j3.close();
		}
	}

	@Test
	public void test4InstancesInLine_ExportAndExecute() throws IOException, JElectroException, InterruptedException {
		JElectro j1 = new JElectro("1");
		JElectro j2 = new JElectro("2");
		JElectro j3 = new JElectro("3");
		JElectro j4 = new JElectro("4");

		log.info("Instanciation successfull");
		try {
			j2.listenTo(12001);
			j1.connectTo("localhost", 12001);
			j3.connectTo("localhost", 12001);
			j3.listenTo(12002);
			j4.connectTo("localhost", 12002);

			Assert.assertEquals(1, j1.getActiveConnections().size());
			Assert.assertEquals(2, j2.getActiveConnections().size());
			Assert.assertEquals(2, j3.getActiveConnections().size());
			Assert.assertEquals(1, j4.getActiveConnections().size());

			log.info("Connection successfull");

			Calc addInstance = new CalcImpl();

			j1.bind("add", addInstance);

			StubSet<Calc> addStubs = j4.lookup("add", Calc.class);

			Calc addStub = addStubs.get(0);

			int sum = addStub.add(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

			log.info("Result is : " + sum);
			Assert.assertEquals(55, sum);
		} finally {
			j1.close();
			j2.close();
			j3.close();
			j4.close();
		}
	}

	@Test
	public void testSingleExportAndExecuteWithCallback() throws IOException, JElectroException, InterruptedException {
		log.info("Start testSingleExportAndExecute");
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		log.info("Instanciation successfull");
		try {
			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Assert.assertEquals(1, j1.getActiveConnections().size());
			Assert.assertEquals(1, j2.getActiveConnections().size());

			log.info("Connection successfull");

			Prime primeInstance = new PrimeImpl();
			j1.bind("prime", primeInstance);

			final LinkedBlockingQueue<Integer> lbQueue = new LinkedBlockingQueue<Integer>();

			Prime primeStub = j2.lookupUnique("prime", Prime.class);
			PrimeSender primeSenderCallBack = new PrimeSender() {

				@Override
				public void onPrime(int primeNumber) {
					log.info("On prime : " + primeNumber);
					lbQueue.add(primeNumber);

				}
			};

			primeStub.getPrimeNumber(12, primeSenderCallBack);
			Assert.assertEquals(2, lbQueue.poll(1, TimeUnit.SECONDS).intValue());
			Assert.assertEquals(3, lbQueue.poll(1, TimeUnit.SECONDS).intValue());
			Assert.assertEquals(5, lbQueue.poll(1, TimeUnit.SECONDS).intValue());
			Assert.assertEquals(7, lbQueue.poll(1, TimeUnit.SECONDS).intValue());
			Assert.assertEquals(11, lbQueue.poll(1, TimeUnit.SECONDS).intValue());

			Assert.assertEquals(0, lbQueue.size());
		} finally {
			j1.close();
			j2.close();
		}
	}

	@Test
	public void testMultipleInstanceExport() throws JElectroException, InterruptedException, IOException {
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		try {

			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Calc add1 = new CalcImpl(10);
			Calc add2 = new CalcImpl(20);

			j1.bind("add1", add1);
			j2.bind("add2", add2);

			Calc add1Stub = j2.lookupUnique("add1", Calc.class);
			Calc add2Stub = j1.lookupUnique("add2", Calc.class);

			int sum1 = add1Stub.add(1, 2, 3);
			Assert.assertEquals(16, sum1);
			Assert.assertEquals(28, add2Stub.add(1, 2, 5));

		} finally {
			j1.close();
			j2.close();
		}
	}

	@Test
	public void testSelfInstanceExport() throws JElectroException, InterruptedException, IOException {
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		try {

			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Calc add1 = new CalcImpl(10);
			Calc add2 = new CalcImpl(20);

			j1.bind("add1", add1);
			j2.bind("add2", add2);

			Calc add1Stub = j1.lookupUnique("add1", Calc.class);
			Calc add2Stub = j2.lookupUnique("add2", Calc.class);

			int sum1 = add1Stub.add(1, 2, 3);
			Assert.assertEquals(16, sum1);
			Assert.assertEquals(28, add2Stub.add(1, 2, 5));

		} finally {
			j1.close();
			j2.close();
		}
	}

	@Test(expected = JElectroException.class)
	public void testExceptionCall() throws Exception {
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		try {

			j1.listenTo(12001);
			j2.connectTo("localhost", 12001);

			Calc calc = new CalcImpl(10);
			j1.bind("calc", calc);

			Calc stub = j2.lookupUnique("calc", Calc.class);
			Assert.assertEquals(5d, stub.divide(10, 2), 0.001d);

			System.out.println(stub.divide(10, 0));

		} finally {
			j1.close();
			j2.close();
		}

	}

	@Test
	public void testInitialExportOfStub() throws Exception {
		JElectro j1 = new JElectro("a");
		JElectro j2 = new JElectro("b");

		try {

			j1.listenTo(12001);

			Calc calc = new CalcImpl(10);
			j1.bind("calc", calc);

			j2.connectTo("localhost", 12001);

			Calc stub = j2.lookupUnique("calc", Calc.class);
			Assert.assertEquals(5d, stub.divide(10, 2), 0.001d);

			Assert.assertEquals(10, stub.divide(10, 1), 0.001d);

		} finally {
			j1.close();
			j2.close();
		}
	}

	@Test(expected = PathNotAvailableException.class)
	public void testPathFailOnSquareNetwork() throws Exception {

		JElectro j1 = new JElectro("1");
		JElectro j2 = new JElectro("2");
		JElectro j3 = new JElectro("3");
		JElectro j4 = new JElectro("4");

		try {

			j2.listenTo(12001);
			j3.listenTo(12002);

			j1.connectTo("localhost", 12001);
			j1.connectTo("localhost", 12002);

			j4.connectTo("localhost", 12001);
			j4.connectTo("localhost", 12002);

			Calc calc = new CalcImpl(0);
			j1.bind("calc", calc);

			Calc calcStub = j4.lookupUnique("calc", Calc.class);

			Assert.assertEquals(60, calcStub.add(10, 20, 30));

			j3.close();
			j2.close();

			// Thread.sleep(100);

			Assert.assertEquals(60, calcStub.add(10, 20, 30));
			// Should throw path not found

		} finally {
			j1.close();
			j2.close();
			j3.close();
			j4.close();
		}
	}

	@Test(expected = PathNotAvailableException.class)
	public void testPathFailOnLineNetwork() throws Exception {

		JElectro j1 = new JElectro("1");
		JElectro j2 = new JElectro("2");
		JElectro j3 = new JElectro("3");
		JElectro j4 = new JElectro("4");

		try {

			j2.listenTo(12001);
			j4.listenTo(12002);

			j1.connectTo("localhost", 12001);
			j3.connectTo("localhost", 12001);
			j3.connectTo("localhost", 12002);

			Calc calc = new CalcImpl(0);
			j1.bind("calc", calc);

			Calc calcStub = j4.lookupUnique("calc", Calc.class);

			Assert.assertEquals(60, calcStub.add(10, 20, 30));

			// j3.close();
			j2.close();

			// Thread.sleep(100);

			Assert.assertEquals(60, calcStub.add(10, 20, 30));
			// Should throw path not found

		} finally {
			j1.close();
			j2.close();
			j3.close();
			j4.close();
		}
	}

	@Test
	public void testSerializationObjectUpdate() throws Exception {

		JElectro j1 = new JElectro("1");
		JElectro j2 = new JElectro("2");
		JElectro j3 = new JElectro("3");
		JElectro j4 = new JElectro("4");

		try {

			j2.listenTo(12001);
			j3.listenTo(12002);

			j1.connectTo("localhost", 12001);
			j1.connectTo("localhost", 12002);

			j4.connectTo("localhost", 12001);
			j4.connectTo("localhost", 12002);

			Calc calc = new CalcImpl(0);
			j1.bind("calc", calc);

			Calc calcStub = j4.lookupUnique("calc", Calc.class);

			int[] ints = new int[] { 1, 2, 3, 4, 5, 6 };

			Assert.assertEquals(21, calcStub.add(ints));

			ints[0] = 11;

			Assert.assertEquals(31, calcStub.add(ints));

		} finally {
			j1.close();
			j2.close();
			j3.close();
			j4.close();
		}
	}

}
